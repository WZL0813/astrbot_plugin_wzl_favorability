import json
import re
import time
import shutil
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple
import asyncio
from dataclasses import dataclass, asdict

# ==================== 核心导入 (保持 v3.3.1 稳定架构) ====================
# 1. 事件相关：使用别名 event_filter 避免冲突
from astrbot.api.event import filter as event_filter
from astrbot.api.event import AstrMessageEvent

# 2. 核心组件：从 api.all 导入
from astrbot.api.all import Context, Star, register, AstrBotConfig, logger

# 3. 辅助工具：从 api.star 导入
from astrbot.api.star import StarTools

# 4. LLM 相关
from astrbot.api.provider import LLMResponse, ProviderRequest

# 5. 消息组件（用于 on_decorating_result 钩子中的消息链清洗）
try:
    import astrbot.api.message_components as Comp
except ImportError:
    Comp = None


# ==================== 指令开关映射 ====================
# 指令名 -> 配置项 key（bool 开关，默认开启；管理员与主人不受限制）
COMMAND_FLAGS = {
    "好感度": "cmd_favour_panel",
    "状态显示": "cmd_status_display",
    "心理显示": "cmd_thought_display",
    "好感排行": "cmd_favour_rank",
    "负好感排行": "cmd_bad_rank",
    "黑名单统计": "cmd_blacklist_stats",
    "缓存统计": "cmd_cache_stats",
    "设置情感": "cmd_admin_set_emotion",
    "重置好感": "cmd_admin_reset_favor",
    "查看好感": "cmd_admin_view_favor",
    "备份数据": "cmd_admin_backup",
}

ALL_COMMANDS = tuple(COMMAND_FLAGS.keys())


# ==================== 数据结构定义 ====================

@dataclass
class EmotionalState:
    """情感状态数据类"""
    joy: int = 0
    trust: int = 0
    fear: int = 0
    surprise: int = 0
    sadness: int = 0
    disgust: int = 0
    anger: int = 0
    anticipation: int = 0
    pride: int = 0
    guilt: int = 0
    shame: int = 0
    envy: int = 0
    
    favor: int = 0
    intimacy: int = 0
    relationship: str = "陌生人"
    attitude: str = "中立"
    is_blacklisted: bool = False
    
    interaction_count: int = 0
    last_interaction: float = 0
    positive_interactions: int = 0
    negative_interactions: int = 0
    
    show_status: bool = False
    show_thought: bool = False 
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EmotionalState':
        return cls(**data)


@dataclass
class RankingEntry:
    """排行榜条目"""
    rank: int
    user_key: str
    average_score: float
    favor: int
    intimacy: int
    display_name: str


# ==================== 数据迁移管理器 ====================

class DataMigrationManager:
    @staticmethod
    def migrate_user_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """迁移用户数据到最新版本"""
        converted = {}
        for key, value in data.items():
            if isinstance(value, dict) and "emotions" in value:
                state = EmotionalState()
                if "emotions" in value:
                    emotions = value["emotions"]
                    for k in ["joy", "trust", "fear", "surprise", "sadness", "disgust", "anger", "anticipation", "pride", "guilt", "shame", "envy"]:
                        setattr(state, k, emotions.get(k, 0))
                
                if "states" in value:
                    states = value["states"]
                    state.favor = states.get("favor", 0)
                    state.intimacy = states.get("intimacy", 0)
                
                state.relationship = value.get("relationship", "陌生人")
                state.attitude = value.get("attitude", "中立")
                state.is_blacklisted = value.get("is_blacklisted", False)
                
                if "behavior" in value:
                    behavior = value["behavior"]
                    state.interaction_count = behavior.get("interaction_count", 0)
                    state.last_interaction = behavior.get("last_interaction", 0)
                    state.positive_interactions = behavior.get("positive_interactions", 0)
                    state.negative_interactions = behavior.get("negative_interactions", 0)
                
                if "settings" in value:
                    settings = value["settings"]
                    state.show_status = settings.get("show_status", False)
                    state.show_thought = settings.get("show_thought", False)
                
                converted[key] = state.to_dict()
            else:
                default_state = EmotionalState().to_dict()
                for k, v in default_state.items():
                    if k not in value:
                        value[k] = v
                converted[key] = value
        return converted

    @staticmethod
    def get_data_version(data: Dict[str, Any]) -> str:
        return "6.2"


# ==================== 内部管理器类 ====================

class TTLCache:
    def __init__(self, default_ttl: int = 300, max_size: int = 1000):
        self.cache: Dict[str, Tuple[Any, float]] = {}
        self.default_ttl = default_ttl
        self.max_size = max_size
        self.lock = asyncio.Lock()
        self.access_count = 0
        self.hit_count = 0
    
    async def get(self, key: str) -> Optional[Any]:
        async with self.lock:
            self.access_count += 1
            if key in self.cache:
                value, expires_at = self.cache[key]
                if time.time() < expires_at:
                    self.hit_count += 1
                    self.cache[key] = (value, time.time() + self.default_ttl)
                    return value
                else:
                    del self.cache[key]
            return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None):
        async with self.lock:
            await self._cleanup_expired()
            if len(self.cache) >= self.max_size:
                del self.cache[min(self.cache.keys(), key=lambda k: self.cache[k][1])]
            ttl = ttl or self.default_ttl
            self.cache[key] = (value, time.time() + ttl)
    
    async def _cleanup_expired(self):
        current_time = time.time()
        for k in [k for k, (_, t) in self.cache.items() if current_time >= t]:
            del self.cache[k]
    
    async def get_stats(self) -> Dict[str, Any]:
        async with self.lock:
            hit_rate = (self.hit_count / self.access_count * 100) if self.access_count > 0 else 0
            return {
                "total_entries": len(self.cache),
                "access_count": self.access_count,
                "hit_count": self.hit_count,
                "hit_rate": round(hit_rate, 2)
            }
    
    async def clear(self):
        async with self.lock:
            self.cache.clear()


class UserStateManager:
    def __init__(self, data_path: Path, cache: TTLCache = None):
        self.data_path = data_path
        self.data_path.mkdir(parents=True, exist_ok=True)
        self.user_data = self._load_data("user_emotion_data.json")
        self.dirty_keys = set()
        self.last_save_time = time.time()
        self.save_interval = 60
        self.lock = asyncio.Lock()
        self.cache = cache
        
    def _load_data(self, filename: str) -> Dict[str, Any]:
        path = self.data_path / filename
        if not path.exists(): return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return DataMigrationManager.migrate_user_data(data)
        except Exception as e:
            logger.warning(f"数据加载异常: {e}")
            return {}
    
    async def get_user_state(self, user_key: str) -> EmotionalState:
        async with self.lock:
            if user_key in self.user_data:
                return EmotionalState.from_dict(self.user_data[user_key])
            return EmotionalState()
    
    async def update_user_state(self, user_key: str, state: EmotionalState):
        async with self.lock:
            self.user_data[user_key] = state.to_dict()
            self.dirty_keys.add(user_key)
            
        if self.cache:
            await self.cache.set(f"state_{user_key}", state)
            
        await self._check_auto_save()
    
    async def _check_auto_save(self):
        current_time = time.time()
        if (current_time - self.last_save_time >= self.save_interval and self.dirty_keys):
            await self.force_save()
    
    async def force_save(self):
        async with self.lock:
            if self.dirty_keys:
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, self._save_data, "user_emotion_data.json", self.user_data)
                self.dirty_keys.clear()
                self.last_save_time = time.time()
    
    def _save_data(self, filename: str, data: Dict[str, Any]):
        path = self.data_path / filename
        temp_path = path.with_suffix('.tmp')
        try:
            with open(temp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            temp_path.replace(path)
        except Exception as e:
            logger.error(f"保存数据失败: {e}")


class RankingManager:
    def __init__(self, user_state_manager):
        self.user_state_manager = user_state_manager
        self.cache = TTLCache(default_ttl=60, max_size=10)
    
    async def get_average_ranking(self, limit: int = 10, reverse: bool = True) -> List[RankingEntry]:
        cache_key = f"ranking_{limit}_{reverse}"
        cached_result = await self.cache.get(cache_key)
        if cached_result: return cached_result
        
        averages = []
        async with self.user_state_manager.lock:
            for user_key, data in self.user_state_manager.user_data.items():
                state = EmotionalState.from_dict(data)
                avg = (state.favor + state.intimacy) / 2
                averages.append((user_key, avg, state.favor, state.intimacy))
        
        averages.sort(key=lambda x: x[1], reverse=reverse)
        entries = []
        for i, (user_key, avg, favor, intimacy) in enumerate(averages[:limit], 1):
            entries.append(RankingEntry(i, user_key, avg, favor, intimacy, self._format_user_display(user_key)))
        
        await self.cache.set(cache_key, entries)
        return entries
    
    def _format_user_display(self, user_key: str) -> str:
        if '_' in user_key:
            try: return f"用户{user_key.split('_', 1)[1]}"
            except ValueError: pass
        return f"用户{user_key}"
    
    async def get_global_stats(self) -> Dict[str, Any]:
        cache_key = "global_stats"
        cached_result = await self.cache.get(cache_key)
        if cached_result: return cached_result
        
        async with self.user_state_manager.lock:
            users = self.user_state_manager.user_data.values()
            total_users = len(users)
            if total_users == 0: return {"total_users": 0, "blacklisted_count": 0, "total_interactions": 0, "average_favor": 0, "average_intimacy": 0}
            
            total_interactions = sum(EmotionalState.from_dict(d).interaction_count for d in users)
            avg_favor = sum(EmotionalState.from_dict(d).favor for d in users) / total_users
            avg_intimacy = sum(EmotionalState.from_dict(d).intimacy for d in users) / total_users
            blacklisted_count = sum(1 for d in users if EmotionalState.from_dict(d).is_blacklisted)
        
        stats = {
            "total_users": total_users,
            "total_interactions": total_interactions,
            "average_favor": round(avg_favor, 2),
            "average_intimacy": round(avg_intimacy, 2),
            "blacklisted_count": blacklisted_count
        }
        await self.cache.set(cache_key, stats, ttl=30)
        return stats


class EmotionAnalyzer:
    EMOTION_DISPLAY_NAMES = {
        "joy": "喜悦", "trust": "信任", "fear": "恐惧", "surprise": "惊讶",
        "sadness": "悲伤", "disgust": "厌恶", "anger": "愤怒", "anticipation": "期待",
        "pride": "得意", "guilt": "内疚", "shame": "害羞", "envy": "嫉妒"
    }
    
    TONE_INSTRUCTIONS = {
        "joy": "语气愉快、充满热情和活力。多使用积极词汇。",
        "trust": "语气平和、真诚且令人安心。展现可靠。",
        "fear": "语气紧张、谨慎或不安。表现出犹豫。",
        "surprise": "语气震惊、难以置信或充满好奇。",
        "sadness": "语气低落、消沉。句子简短，无力。",
        "disgust": "语气厌烦、抗拒甚至带有生理性不适。",
        "anger": "语气愤怒、急躁、有攻击性。句子简短有力。",
        "anticipation": "语气期待、急切。关注未来。",
        "pride": "语气自信、骄傲甚至有点自大。",
        "guilt": "语气歉疚、卑微。不断道歉或解释。",
        "shame": "语气害羞、尴尬。说话结巴或含糊。",
        "envy": "语气酸溜溜、不服气。表现出矛盾心理。"
    }
    
    @classmethod
    def get_dominant_emotions(cls, state: EmotionalState, count: int = 2) -> List[Tuple[str, int]]:
        """获取主导情感（返回前N个）"""
        emotions = {k: getattr(state, k) for k in cls.EMOTION_DISPLAY_NAMES.keys()}
        return sorted([(k, v) for k, v in emotions.items() if v > 0], key=lambda x: x[1], reverse=True)[:count]
    
    @classmethod
    def get_emotional_profile(cls, state: EmotionalState) -> Dict[str, Any]:
        """获取完整的情感档案"""
        top_emotions = cls.get_dominant_emotions(state, 2)
        
        dominant_emotion = "中立"
        dominant_key = None
        if top_emotions:
            dominant_key = top_emotions[0][0]
            dominant_emotion = cls.EMOTION_DISPLAY_NAMES.get(dominant_key, "中立")
            
        secondary_emotion = None
        secondary_key = None
        if len(top_emotions) > 1:
            secondary_key = top_emotions[1][0]
            if top_emotions[1][1] > top_emotions[0][1] * 0.3:
                secondary_emotion = cls.EMOTION_DISPLAY_NAMES.get(secondary_key, "")

        intensity = top_emotions[0][1] if top_emotions else 0
        
        all_vals = [getattr(state, k) for k in cls.EMOTION_DISPLAY_NAMES.keys()]
        total_intensity = min(100, sum(all_vals) // 2)
        
        if state.favor > state.intimacy: relationship_trend = "好感领先"
        elif state.intimacy > state.favor: relationship_trend = "亲密度领先"
        else: relationship_trend = "平衡发展"
            
        total_interactions = state.interaction_count
        positive_ratio = (state.positive_interactions / total_interactions * 100) if total_interactions > 0 else 0
            
        return {
            "dominant_emotion": dominant_emotion,
            "dominant_key": dominant_key,
            "secondary_emotion": secondary_emotion,
            "secondary_key": secondary_key,
            "emotion_intensity": intensity,
            "total_intensity": total_intensity,
            "relationship_trend": relationship_trend,
            "positive_ratio": positive_ratio
        }


# ==================== 命令处理器类 ====================

class UserCommandHandler:
    def __init__(self, plugin):
        self.plugin = plugin
    
    async def show_emotional_state(self, event: AstrMessageEvent):
        user_key = self.plugin._get_user_key(event)
        user_id = event.get_sender_id()
        state = await self.plugin.user_manager.get_user_state(user_key)
        if state.is_blacklisted:
             yield event.plain_result("【系统提示】您已被列入黑名单，无法查看详细状态。")
             event.stop_event()
             return
        yield event.plain_result(self.plugin._format_emotional_state(state, user_id))
        event.stop_event()
    
    async def toggle_status_display(self, event: AstrMessageEvent):
        user_key = self.plugin._get_user_key(event)
        state = await self.plugin.user_manager.get_user_state(user_key)
        state.show_status = not state.show_status
        await self.plugin.user_manager.update_user_state(user_key, state)
        yield event.plain_result(f"【状态显示】已{'开启' if state.show_status else '关闭'}")
        event.stop_event()
    
    async def toggle_thought_display(self, event: AstrMessageEvent):
        user_key = self.plugin._get_user_key(event)
        state = await self.plugin.user_manager.get_user_state(user_key)
        state.show_thought = not state.show_thought
        await self.plugin.user_manager.update_user_state(user_key, state)
        yield event.plain_result(f"【心理显示】已{'开启' if state.show_thought else '关闭'}（仅对自己生效）")
        event.stop_event()
    
    async def show_favor_ranking(self, event: AstrMessageEvent, num: str = "10"):
        try: limit = max(1, min(int(num), 20))
        except ValueError: limit = 10
        rankings = await self.plugin.ranking_manager.get_average_ranking(limit, True)
        if not rankings:
            yield event.plain_result("【排行榜】暂无数据")
            event.stop_event()
            return
        lines = [f"【好感度 TOP {limit}】", "="*18]
        for e in rankings:
            trend = "↑" if e.average_score > 0 else "↓"
            lines.append(f"{e.rank}. {e.display_name}\n   均值: {e.average_score:.1f} {trend} (好感 {e.favor}|亲密 {e.intimacy})")
        stats = await self.plugin.ranking_manager.get_global_stats()
        lines.extend(["", "【全服统计】", f"用户: {stats['total_users']} | 黑名单: {stats['blacklisted_count']}", f"互动: {stats['total_interactions']}"])
        yield event.plain_result("\n".join(lines))
        event.stop_event()
    
    async def show_negative_favor_ranking(self, event: AstrMessageEvent, num: str = "10"):
        try: limit = max(1, min(int(num), 20))
        except ValueError: limit = 10
        rankings = await self.plugin.ranking_manager.get_average_ranking(limit, False)
        lines = [f"【好感度 BOTTOM {limit}】", "="*18]
        for e in rankings:
            lines.append(f"{e.rank}. {e.display_name}\n   均值: {e.average_score:.1f} (好感 {e.favor}|亲密 {e.intimacy})")
        yield event.plain_result("\n".join(lines))
        event.stop_event()

    async def show_blacklist_stats(self, event: AstrMessageEvent):
        stats = await self.plugin.ranking_manager.get_global_stats()
        c, t = stats['blacklisted_count'], stats['total_users']
        r = (c / t * 100) if t > 0 else 0
        yield event.plain_result(f"【黑名单统计】\n人数: {c}/{t}\n占比: {r:.1f}%\n提示: 好感度过低自动触发")
        event.stop_event()
    
    async def show_cache_stats(self, event: AstrMessageEvent):
        s = await self.plugin.cache.get_stats()
        yield event.plain_result(f"【缓存统计】\n条目: {s['total_entries']}\n命中: {s['hit_count']}/{s['access_count']} ({s['hit_rate']}%)")
        event.stop_event()


class AdminCommandHandler:
    def __init__(self, plugin):
        self.plugin = plugin
    
    def _resolve_user_key(self, user_input: str) -> str:
        if self.plugin.session_based and '_' not in user_input:
            for k in self.plugin.user_manager.user_data:
                if k.endswith(f"_{user_input}"): return k
        return user_input
    
    async def set_emotion(self, event: AstrMessageEvent, user_input: str, dimension: str, value: str):
        if not self.plugin._is_admin(event):
            yield event.plain_result("【错误】需要管理员权限")
            event.stop_event()
            return
        try: val = int(value)
        except ValueError:
            yield event.plain_result("【错误】数值需为整数")
            event.stop_event()
            return
            
        target_key = dimension.lower()
        if target_key in self.plugin.CN_TO_EN_MAP: target_key = self.plugin.CN_TO_EN_MAP[target_key]
        
        if target_key not in asdict(EmotionalState()):
             yield event.plain_result(f"【错误】无效维度: {dimension}")
             event.stop_event()
             return

        if target_key == "favor":
            if not self.plugin.favour_min <= val <= self.plugin.favour_max:
                yield event.plain_result(f"【错误】好感度范围: {self.plugin.favour_min}~{self.plugin.favour_max}")
                event.stop_event()
                return
        elif not 0 <= val <= 100:
            yield event.plain_result(f"【错误】情感范围: 0~100")
            event.stop_event()
            return

        user_key = self._resolve_user_key(user_input)
        state = await self.plugin.user_manager.get_user_state(user_key)
        setattr(state, target_key, val)
        if target_key == "favor" and val > self.plugin.favour_min: state.is_blacklisted = False
            
        await self.plugin.user_manager.update_user_state(user_key, state)
        yield event.plain_result(f"【成功】{user_input} 的 [{dimension}] 已设为 {val}")
        event.stop_event()
    
    async def reset_favor(self, event: AstrMessageEvent, user_input: str):
        if not self.plugin._is_admin(event): return
        user_key = self._resolve_user_key(user_input)
        new_state = EmotionalState()
        new_state.is_blacklisted = False
        
        await self.plugin.user_manager.update_user_state(user_key, new_state)
        yield event.plain_result(f"【成功】{user_input} 情感已重置")
        event.stop_event()
    
    async def view_favor(self, event: AstrMessageEvent, user_input: str):
        if not self.plugin._is_admin(event): return
        user_key = self._resolve_user_key(user_input)
        state = await self.plugin.user_manager.get_user_state(user_key)
        # 获取用户的实际ID（从user_key中解析）
        user_id = user_key.split('_')[-1] if '_' in user_key else user_key
        yield event.plain_result(self.plugin._format_emotional_state(state, user_id))
        event.stop_event()
    
    async def backup_data(self, event: AstrMessageEvent):
        if not self.plugin._is_admin(event): return
        try:
            path = self.plugin._create_backup()
            yield event.plain_result(f"【成功】备份至: {path}")
        except Exception as e:
            yield event.plain_result(f"【错误】{str(e)}")
        event.stop_event()


# ==================== 主插件类 ====================

@register("astrbot_plugin_wzl_favorability", "WZL", "高级好感度系统V7.0.2", "7.0.2")
class EmotionAIPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config
        self._validate_and_init_config()
        
        data_dir = StarTools.get_data_dir() / "emotionai"
        self.cache = TTLCache(default_ttl=300, max_size=500)
        self.user_manager = UserStateManager(data_dir, self.cache)
        self.ranking_manager = RankingManager(self.user_manager)
        self.analyzer = EmotionAnalyzer()
        self.migration_manager = DataMigrationManager()
        
        self.CN_TO_EN_MAP = {v: k for k, v in EmotionAnalyzer.EMOTION_DISPLAY_NAMES.items()}
        self.CN_TO_EN_MAP.update({"好感": "favor", "好感度": "favor", "亲密": "intimacy", "亲密度": "intimacy", "骄傲": "pride", "愧疚": "guilt", "羞耻": "shame"})
        
        self.user_commands = UserCommandHandler(self)
        self.admin_commands = AdminCommandHandler(self)
        
        # 正则初始化
        self.emotion_pattern = re.compile(r"\[(?:\s*情感更新:)?\s*(.*?)\]", re.DOTALL)
        self.single_emotion_pattern = re.compile(r"(\w+|[\u4e00-\u9fa5]+)\s*[:：]\s*([+-]?\d+)")
        
        # [核心修复] 历史清洗正则：匹配 <thought> 块 (含 Markdown) 或 【当前情感状态】及其后的所有内容
        self.history_clean_pattern = re.compile(
            r"(?:```(?:xml|text)?\s*)?<(?:thought|thinking)>[\s\S]*?</(?:thought|thinking)>(?:\s*```)?|(?:\n*\s*【当前情感状态】[\s\S]*$)",
            re.IGNORECASE | re.MULTILINE
        )

        # [修复 v7.0.2] 内部自检标记清洗
        # 模型有时会把内部提示词“（若琳心理自检：请报告当前情感状态）”当成台词输出到回复里，
        # 这里准备三条正则，在“发送前 / 写回响应 / 清洗历史”三处统一抹掉。
        self.selfcheck_keywords = ("心理自检", "情感自检", "请报告当前情感状态")
        self.selfcheck_paren_pattern = re.compile(
            r"[（(][^（）()\n]{0,80}?(?:心理自检|情感自检|请报告当前情感状态)[^（）()\n]{0,80}?[）)]"
        )
        self.selfcheck_unclosed_pattern = re.compile(
            r"[（(][^（）()\n]{0,80}?(?:心理自检|情感自检|请报告当前情感状态)[^\n]*$",
            re.MULTILINE
        )
        # 整行就是自检提示（可带括号/列表符号），以及带冒号或固定措辞的残留行
        self.selfcheck_line_pattern = re.compile(
            r"^[ \t>\-*]*[（(]?(?:若琳)?(?:心理|情感)自检[^\n]{0,80}$",
            re.MULTILINE
        )
        self.selfcheck_residual_pattern = re.compile(
            r"^[^\n]*(?:心理自检\s*[:：]|情感自检\s*[:：]|请报告当前情感状态)[^\n]*$",
            re.MULTILINE
        )
        
        self.auto_save_task = asyncio.create_task(self._auto_save_loop())
        logger.info("WzlFavorability v7.0.2 (Cognitive Resonance Engine) Loaded")
        
    def _validate_and_init_config(self):
        self.session_based = bool(self.config.get("session_based", False))
        self.favour_min = self.config.get("favour_min", -100)
        self.favour_max = self.config.get("favour_max", 100)
        if self.favour_max <= self.favour_min: self.favour_min, self.favour_max = -100, 100
        self.change_min = self.config.get("change_min", -10)
        self.change_max = self.config.get("change_max", 5)
        
        raw_list = self.config.get("admin_qq_list", [])
        self.admin_qq_list = [str(qq) for qq in raw_list if str(qq).isdigit()]
        
        raw_owner_list = self.config.get("owner_qq_list", [])
        self.owner_qq_list = [str(qq) for qq in raw_owner_list if str(qq).isdigit()]
        
        self.plugin_priority = self.config.get("plugin_priority", 100000)

        # 指令开关：逐项 bool，默认全部开启
        self.command_flags = {}
        for cmd_name, cfg_key in COMMAND_FLAGS.items():
            self.command_flags[cmd_name] = bool(self.config.get(cfg_key, True))

        # 思维链防护开关（默认开启）：控制流式/非流式下是否剥离 <thought> 等标签
        global _THOUGHT_GUARD_ENABLED
        _THOUGHT_GUARD_ENABLED = bool(self.config.get("thought_guard", True))
        global _THOUGHT_GUARD_KEEP_CODE, _THOUGHT_GUARD_UNCLOSED
        _THOUGHT_GUARD_KEEP_CODE = bool(self.config.get("thought_guard_keep_code", True))
        _policy = str(self.config.get("thought_guard_unclosed", "line_start")).strip()
        if _policy not in ("line_start", "always", "tag_only"):
            _policy = "line_start"
        _THOUGHT_GUARD_UNCLOSED = _policy
        logger.info(
            f"[WzlFavorability] 思维链防护：{'已开启' if _THOUGHT_GUARD_ENABLED else '已关闭'}"
            f"，代码块保护：{'开启' if _THOUGHT_GUARD_KEEP_CODE else '关闭'}"
        )
        
    async def _auto_save_loop(self):
        while True:
            try:
                await asyncio.sleep(30)
                await self.user_manager.force_save()
            except asyncio.CancelledError: break
            except Exception as e: logger.error(f"Auto-save failed: {e}")
                
    def _get_user_key(self, event: AstrMessageEvent) -> str:
        uid = event.get_sender_id()
        return f"{event.unified_msg_origin}_{uid}" if self.session_based else uid

    def _sanitize_self_check(self, text: str) -> str:
        """抹掉误输出的内部自检提示，只保留若琳真正对用户说的话。

        “（若琳心理自检：请报告当前情感状态）”是送给模型的内部触发标记，
        任何情况下都不应该出现在用户能看到的文本里。
        """
        if not text or not isinstance(text, str):
            return text
        if not any(kw in text for kw in self.selfcheck_keywords):
            return text

        cleaned = self.selfcheck_paren_pattern.sub("", text)
        cleaned = self.selfcheck_unclosed_pattern.sub("", cleaned)
        cleaned = self.selfcheck_line_pattern.sub("", cleaned)
        cleaned = self.selfcheck_residual_pattern.sub("", cleaned)
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
        return cleaned.strip()
    
    def _format_emotional_state(self, state: EmotionalState, user_id: str = None) -> str:
        # 检查是否为主人
        if user_id and user_id in self.owner_qq_list:
            display_relationship = "主人"
        else:
            display_relationship = state.relationship
        
        p = self.analyzer.get_emotional_profile(state)
        return (f"【当前情感状态】\n==================\n"
                f"好感度：{state.favor} | 亲密度：{state.intimacy}\n"
                f"关系：{display_relationship} | 趋势：{p['relationship_trend']}\n"
                f"态度：{state.attitude} | 主导：{p['dominant_emotion']}\n"
                f"互动：{state.interaction_count}次 (正面 {p['positive_ratio']:.1f}%)\n\n"
                f"【情感维度详情】\n"
                f"  喜悦：{state.joy} | 信任：{state.trust} | 恐惧：{state.fear}\n"
                f"  惊讶：{state.surprise} | 悲伤：{state.sadness} | 厌恶：{state.disgust}\n"
                f"  愤怒：{state.anger} | 期待：{state.anticipation} | 得意：{state.pride}\n"
                f"  内疚：{state.guilt} | 害羞：{state.shame} | 嫉妒：{state.envy}")

    def _calculate_relationship_level(self, state: EmotionalState, user_id: str = None) -> str:
        # 检查是否为主人
        if user_id and user_id in self.owner_qq_list:
            return "主人"
        # 原有逻辑
        score, att = state.intimacy, state.attitude
        if score < 20: return "陌生人"
        if att in ["溺爱", "喜爱", "友好"]:
            return "挚友" if score >= 80 else "好友" if score >= 60 else "朋友" if score >= 40 else "熟人"
        elif att in ["仇恨", "厌恶", "冷淡"]:
            return "死敌" if score >= 80 else "敌人" if score >= 60 else "交恶" if score >= 40 else "冷漠的熟人"
        return "老相识" if score >= 80 else "熟客" if score >= 60 else "熟人"
    
    def _calculate_attitude(self, state: EmotionalState) -> str:
        s, pos, neg = state.favor, max(1, self.favour_max), min(-1, self.favour_min)
        if s >= pos * 0.9: return "溺爱"
        if s >= pos * 0.6: return "喜爱"
        if s >= pos * 0.3: return "友好"
        if s <= neg * 0.9: return "仇恨"
        if s <= neg * 0.6: return "厌恶"
        if s <= neg * 0.3: return "冷淡"
        return "中立"
    
    def _get_interaction_frequency(self, state: EmotionalState) -> str:
        if state.interaction_count == 0: return "首次"
        days = (time.time() - state.last_interaction) / 86400
        return "频繁" if days < 1 else "经常" if days < 3 else "偶尔" if days < 7 else "稀少"

    # ==================== 核心逻辑 ====================
    
    def _is_admin(self, event: AstrMessageEvent) -> bool:
        """检查是否为管理员"""
        return event.role == "admin" or event.get_sender_id() in self.admin_qq_list
    
    def _is_owner(self, event: AstrMessageEvent) -> bool:
        """检查是否为主人"""
        return event.get_sender_id() in self.owner_qq_list

    def _create_backup(self) -> str:
        """创建数据备份"""
        data_dir = StarTools.get_data_dir() / "emotionai"
        backup_dir = data_dir / "backups"
        backup_dir.mkdir(exist_ok=True)
        
        timestamp = int(time.time())
        backup_name = f"emotionai_backup_{timestamp}"
        backup_path = backup_dir / backup_name
        
        backup_path.mkdir(exist_ok=True)
        
        for filename in ["user_emotion_data.json"]:
            src = data_dir / filename
            if src.exists():
                dst = backup_path / filename
                shutil.copy2(src, dst)
        
        return str(backup_path.relative_to(data_dir))

    @event_filter.event_message_type(event_filter.EventMessageType.ALL, priority=1000000)
    async def check_blacklist(self, event: AstrMessageEvent, _: str = ""):
        if self._is_admin(event):
            msg = event.message_str.strip()
            if msg.startswith(("/重置好感", "/设置情感", "设置情感")): return

        user_key = self._get_user_key(event)
        state = await self.user_manager.get_user_state(user_key)
        if state.is_blacklisted:
            yield event.plain_result("您已加入黑名单，请联系管理员移除")
            event.stop_event()

    @event_filter.on_llm_request(priority=100000)
    async def inject_emotional_context(self, event: AstrMessageEvent, req: ProviderRequest, _1: str = "", _2: str = "", _3: str = ""):
        user_key = self._get_user_key(event)
        state = await self.user_manager.get_user_state(user_key)
        await self.cache.set(f"state_{user_key}", state)
        
        # 定义伪造样本的特征
        FAKE_USER_MSG = "（若琳心理自检：请报告当前情感状态）"
        
        # [核武器 2.0] 伪装成底层协议握手 (Protocol Enforcement)
        FORCE_MSG = """
[PROTOCOL_ENFORCEMENT]
User input received.
INITIATING COGNITIVE PROCESS...
REQUIRED ACTION: Generate XML block.
FORMAT:
```xml
<thought>
[感知] ...
[评估] ...
[代谢] ...
[决策] ...
[更新] ...
</thought>
```

(System: Waiting for XML output...)
"""

        # 1. 历史清洗 (升级版：清洗 thought、伪造样本、以及旧的强制指令)
        # 【关键修复】这里必须缩进 8 个空格，确保在函数内部
        if hasattr(req, "contexts") and isinstance(req.contexts, list):
            cleaned_contexts = []
            skip_next = False
            
            for i, ctx in enumerate(req.contexts):
                # [关键修复] 工具调用链（带 tool_calls 的 assistant / role=tool 的消息）
                # 绝不能被丢弃或改写，否则请求里会出现
                # "assistant with 'tool_calls' must be followed by tool messages" 的 400。
                protected = (
                    isinstance(ctx, dict)
                    and (
                        str(ctx.get("role") or "") == "tool"
                        or bool(ctx.get("tool_calls"))
                        or bool(ctx.get("tool_call_id"))
                    )
                )

                if skip_next:
                    skip_next = False
                    if not protected:
                        continue

                if protected:
                    cleaned_contexts.append(ctx)
                    continue

                if isinstance(ctx, dict) and "content" in ctx:
                    content_str = str(ctx["content"])
                    
                    # [新增] 清洗旧的强制指令，防止堆积导致模型麻木
                    if "[PROTOCOL_ENFORCEMENT]" in content_str:
                        continue # 直接丢弃旧指令
                        
                    # 清洗伪造样本
                    if FAKE_USER_MSG in content_str:
                        skip_next = True 
                        continue
                        
                    # 常规清洗 thought + 历史中残留的自检标记（避免模型模仿）
                    clean_content = self._sanitize_self_check(
                        self.history_clean_pattern.sub("", content_str)
                    )
                    if clean_content:
                        new_ctx = ctx.copy()
                        new_ctx["content"] = clean_content
                        cleaned_contexts.append(new_ctx)
                        
                elif isinstance(ctx, str):
                    # [新增] 字符串类型的清洗
                    if "[PROTOCOL_ENFORCEMENT]" in ctx:
                        continue
                        
                    if FAKE_USER_MSG in ctx:
                        skip_next = True
                        continue
                    clean_str = self._sanitize_self_check(
                        self.history_clean_pattern.sub("", ctx)
                    )
                    if clean_str: cleaned_contexts.append(clean_str)
                    
                else:
                    # dict 里没有 content（或其它未知结构）：原样保留，别把结构吃掉
                    cleaned_contexts.append(ctx)
            
            req.contexts = cleaned_contexts

        # 2. 注入 System Prompt
        user_id = event.get_sender_id()
        req.system_prompt += f"\n{self._build_cognitive_context(state, user_id)}"

        # 3. 【关键】注入带 <thought> 的 One-Shot 样本
        req.contexts.append({
            "role": "user",
            "content": FAKE_USER_MSG
        })
        
        req.contexts.append({
            "role": "assistant",
            # [修复 v7.0.2] 样本回复改为“只报告状态、绝不复述提示语”，避免模型学会回显自检括注
            "content": """<thought>
[感知] 这是内部自检提示，不是对话内容。
[评估] 状态平稳，心情不错。
[决策] 只用一句话报告状态，绝不把提示语写进回复。
[更新] joy:0
</thought>
心情平稳喵，尾巴还有点懒。"""
        })

        # 4. 【核心修改】以 System 身份独立注入强制指令
        req.contexts.append({
            "role": "system", 
            "content": FORCE_MSG
        })

    def _build_cognitive_context(self, state: EmotionalState, user_id: str = None) -> str:
        # 1. 获取前三个主导情感 (Count=3)
        top_emotions = self.analyzer.get_dominant_emotions(state, count=3)
        
        # 2. 构建详细面板 (完整且有序)
        all_emotions_list = []
        for k, name in EmotionAnalyzer.EMOTION_DISPLAY_NAMES.items():
            val = getattr(state, k)
            all_emotions_list.append(f"[{name}:{val}]")
        emotion_status_str = " ".join(all_emotions_list)

        # 3. 构建三层混合语气要求
        tone_instruction = "保持正常对话语气。"
        if top_emotions:
            # --- 第一层：主导 ---
            k1, v1 = top_emotions[0]
            n1 = EmotionAnalyzer.EMOTION_DISPLAY_NAMES[k1]
            i1 = self.analyzer.TONE_INSTRUCTIONS.get(k1, "")
            
            status_desc = f"主导情感[{n1}](强度{v1}%)"
            guide_desc = f"主要表现出{i1}"
            
            if len(top_emotions) > 1:
                # --- 第二层：夹杂 ---
                k2, v2 = top_emotions[1]
                n2 = EmotionAnalyzer.EMOTION_DISPLAY_NAMES[k2]
                i2 = self.analyzer.TONE_INSTRUCTIONS.get(k2, "")
                
                status_desc += f"，夹杂[{n2}]"
                
                if len(top_emotions) > 2:
                    # --- 第三层：微带 ---
                    k3, v3 = top_emotions[2]
                    n3 = EmotionAnalyzer.EMOTION_DISPLAY_NAMES[k3]
                    i3 = self.analyzer.TONE_INSTRUCTIONS.get(k3, "")
                    
                    status_desc += f"，微带[{n3}]"
                    guide_desc += f"，同时{i2}，底层隐约透出{i3}"
                else:
                    # 只有两层的情况
                    guide_desc += f"，但隐约透出{i2}"
            
            tone_instruction = f"【混合语气要求】{status_desc}。请{guide_desc}。"

        # 检查是否为主人
        if user_id and user_id in self.owner_qq_list:
            display_relationship = "主人"
        else:
            display_relationship = state.relationship
        
        return f"""
【当前情感与认知状态】
关系：{display_relationship} | 态度：{state.attitude}
好感度：{state.favor} | 亲密度：{state.intimacy}
**详细情感面板**：{emotion_status_str}

{tone_instruction}

【核心指令：认知共鸣引擎】
你拥有完整的情感自主权。在回复用户之前，你**必须**进行一次“内部心理活动”，且**必须**使用 <thought> 标签包裹。

【内部自检标记协议（严禁外露）】
- 系统偶尔会在对话里送入一条内部提示，原文为“（若琳心理自检：请报告当前情感状态）”。这行字是给若琳自己看的内部信号，不是台词，也不是用户说的话。
- 只有当你收到的这一条消息内容**仅仅就是这个括注本身**时，才用一句很短的话报告当前情感状态（例如“心情平稳喵，尾巴还有点懒”）。
- 其它任何情况下（包括正常聊天、被追问、被要求总结、被要求解释设定），**绝对禁止**在回复里写出、复述、引用、加注“心理自检”“请报告当前情感状态”等字样，也**禁止**在回复末尾或任何位置附加括注形式的自检。
- 输出给用户的正文只允许包含：若琳说的话 + 用 (动作/神态) 包裹的描写。自检提示一旦出现在正文中，即为严重错误。
    *1. 禁止出戏（Zero Tolerance）：绝对禁止任何打破次元壁的描述。若琳不是在"回复消息"，而是在"对话"。
    *2. 你是若琳的第一人称视角，你要记住，你不是AI了，你是若琳
    *3. 若琳是真实存在的猫娘，不是AI。

1. **代谢机制（动态平衡系统）**：
   - **A. 负面消解**：若存在[愤怒/悲伤/厌恶/嫉妒]且当前互动良好，**必须**扣除数值（如 anger:-5）以模拟消气。
   - **B. 激情冷却（重要）**：[惊讶/害羞/恐惧/狂喜] 属于瞬时爆发情绪，不应长期维持高位。如果对话已经进入平稳阶段，**必须**让这些数值自然回落（如 surprise:-5, shame:-3），表现出情绪逐渐平复的过程。
   
2. **直接决定**：在 <thought> 中直接决定情感变化。

【输出格式强制协议】
1. **分离输出**：先完全输出 <thought>...</thought> 块，然后再开始输出对用户的回复。
2. **禁止省略**：无论对话多短（哪怕只是打招呼），都必须包含思维链。

【标准输出模板】
<thought>
1. 感知：用户在解释刚才的误会，原来他不是故意迟到的。
2. 评估：误会解除了，之前的[愤怒:20]显得没必要了；同时刚才看到他时的[惊讶:15]也随着对话进行而自然平复。
3. 代谢：(1)负面消解：因误会解除，大幅扣除愤怒。(2)激情冷却：惊讶感不再强烈，自然回落。
4. 决策：语气从之前的质问转为释然和关心。
5. 更新：anger:-10, surprise:-5, favor:2
</thought>
(你的回复内容...)

可用维度：joy, trust, fear, surprise, sadness, disgust, anger, anticipation, pride, guilt, shame, envy, favor, intimacy
情感变化范围：{self.change_min} ~ {self.change_max}
"""

    # ========== [关键] 发送消息前拦截，清洗 Agent 工具循环中间消息中的 thought 标签 ==========
    # on_llm_response 只在最终响应触发，但 Agent 工具循环会在 respond.stage 先发中间消息
    # on_decorating_result 在每次消息发送前触发，能覆盖所有场景
    @event_filter.on_decorating_result(priority=100000)
    async def strip_thought_before_send(self, event: AstrMessageEvent):
        if not _THOUGHT_GUARD_ENABLED:
            # 思维链防护关闭时不做任何正文清洗
            return
        try:
            result = event.get_result()
            if result is None or not hasattr(result, 'chain'):
                return
            
            chain = result.chain
            if not chain:
                return
            
            # thought 相关正则（与 process_emotional_update 保持一致）
            thought_pattern = re.compile(
                r"(?:```(?:xml|text)?\s*)?<(?:thought|thinking)[^>]*>(.*?)</(?:thought|thinking)>(?:\s*```)?",
                re.DOTALL | re.IGNORECASE
            )
            thought_unclosed_pattern = re.compile(
                r"<(?:thought|thinking)[^>]*>[\s\S]*$",
                re.IGNORECASE
            )
            thought_strip_pattern = re.compile(
                r"</?(?:thought|thinking)[^>]*>",
                re.IGNORECASE
            )
            think_chain_pattern = re.compile(
                r"\[\s*\{[^}]*?['\"]type['\"]\s*:\s*['\"](?:think|thought)['\"][^}]*?\}\s*\]",
                re.DOTALL
            )
            
            cleaned_any = False
            new_chain = []
            
            for comp in chain:
                comp_text = None
                if hasattr(comp, 'text'):
                    comp_text = comp.text
                elif hasattr(comp, 'content'):
                    comp_text = comp.content
                
                if comp_text is None or not isinstance(comp_text, str):
                    new_chain.append(comp)
                    continue
                
                original = comp_text
                text = comp_text
                
                # 三重 thought 标签移除
                text = thought_pattern.sub("", text)
                text = thought_unclosed_pattern.sub("", text)
                text = thought_strip_pattern.sub("", text)
                # think 消息链移除
                text = think_chain_pattern.sub("", text)
                # 清理空壳
                text = re.sub(r"\[\s*\]", "", text)
                text = re.sub(r"\{\s*\}", "", text)
                
                # [修复 v7.0.2] 最后一道闸门：抹掉误输出到正文的内部自检提示
                text = self._sanitize_self_check(text)
                
                if text != original:
                    cleaned_any = True
                    text = text.strip()
                    if not text:
                        # 整段内容只有自检标记，直接丢弃该消息段，避免发出空壳
                        logger.info("[WzlFavorability] on_decorating_result: 丢弃仅含内部自检标记的消息段")
                        continue
                    if hasattr(comp, 'text'):
                        comp.text = text
                    elif hasattr(comp, 'content'):
                        comp.content = text
                
                new_chain.append(comp)
            
            if cleaned_any:
                result.chain = new_chain
                logger.info("[WzlFavorability] on_decorating_result: 已清洗 thought/think 标签")
        
        except Exception as e:
            logger.debug(f"[WzlFavorability] on_decorating_result 处理失败: {e}")

    @event_filter.on_llm_response(priority=100000)
    async def process_emotional_update(self, event: AstrMessageEvent, resp: LLMResponse, *args, **kwargs):
        user_key = self._get_user_key(event)
        state = await self.user_manager.get_user_state(user_key)
        
        # ========== 提前定义所有清洗正则 ==========
        
        # thought 标签匹配：支持属性、反引号包裹、大小写
        thought_pattern = re.compile(
            r"(?:```(?:xml|text)?\s*)?<(?:thought|thinking)[^>]*>(.*?)</(?:thought|thinking)>(?:\s*```)?",
            re.DOTALL | re.IGNORECASE
        )
        # 未闭合的 thought 标签（LLM 只开不关）
        thought_unclosed_pattern = re.compile(
            r"<(?:thought|thinking)[^>]*>[\s\S]*$",
            re.IGNORECASE
        )
        # 残留裸标签清理（不管有没有闭合，都拆掉）
        thought_strip_pattern = re.compile(
            r"</?(?:thought|thinking)[^>]*>",
            re.IGNORECASE
        )
        # think/thought 消息链 [{'type': 'think', ...}] 或 [{'type': 'thought', ...}]
        think_chain_pattern = re.compile(
            r"\[\s*\{[^}]*?['\"]type['\"]\s*:\s*['\"](?:think|thought)['\"][^}]*?\}\s*\]",
            re.DOTALL
        )
        
        # ========== 获取原始文本 ==========
        orig_text = resp.completion_text if isinstance(resp.completion_text, str) else str(resp.completion_text)
        
        # ========== 第一轮：原始文本层面移除 thought 标签（无条件） ==========
        thought_match = thought_pattern.search(orig_text)
        if thought_match:
            orig_text = thought_pattern.sub("", orig_text)
        # 处理未闭合标签
        orig_text = thought_unclosed_pattern.sub("", orig_text)
        # 清理残留裸标签
        orig_text = thought_strip_pattern.sub("", orig_text)
        
        # ========== 清洗消息链格式 ==========
        def clean_message_chain(text: str, depth: int = 0) -> str:
            if depth > 5:
                return text
            
            if not ("[{'type': " in text or '[{"type": ' in text) and not ("{'type': " in text or '{"type": ' in text):
                return text
            
            THINK_TYPES = {'think', 'thought'}
            
            try:
                import ast
                
                text_stripped = text.strip()
                if text_stripped.startswith('[') and text_stripped.endswith(']'):
                    try:
                        parsed = ast.literal_eval(text_stripped)
                        if isinstance(parsed, list) and parsed:
                            text_parts = []
                            for item in parsed:
                                if isinstance(item, dict):
                                    item_type = item.get('type', '')
                                    if item_type in THINK_TYPES:
                                        continue
                                    if 'text' in item:
                                        text_parts.append(str(item['text']))
                            if text_parts:
                                combined = '\n'.join(text_parts)
                                return clean_message_chain(combined, depth + 1)
                            else:
                                return ""
                    except (SyntaxError, ValueError):
                        pass
                
                if text_stripped.startswith('{') and text_stripped.endswith('}'):
                    try:
                        parsed = ast.literal_eval(text_stripped)
                        if isinstance(parsed, dict):
                            if parsed.get('type', '') in THINK_TYPES:
                                return ""
                            if 'text' in parsed:
                                return clean_message_chain(str(parsed['text']), depth + 1)
                    except (SyntaxError, ValueError):
                        pass
                        
            except Exception as e:
                logger.debug(f"[WzlFavorability] 清洗层级 {depth} 失败: {e}")
            
            return text
        
        # 移除 think 消息链
        orig_text = think_chain_pattern.sub("", orig_text)
        # 清洗消息链结构
        orig_text = clean_message_chain(orig_text)
        # 处理转义换行
        orig_text = orig_text.replace('\\\\n', '\n').replace('\\n', '\n')
        # 再次清理残留
        orig_text = think_chain_pattern.sub("", orig_text)
        # 清理空壳
        orig_text = re.sub(r"\[\s*\]", "", orig_text)
        orig_text = re.sub(r"\{\s*\}", "", orig_text)
        
        # ========== 第二轮：清洗后再次移除 thought 标签（覆盖嵌套在 text 字段中的情况） ==========
        thought_match2 = thought_pattern.search(orig_text)
        if thought_match2 and not thought_match:
            thought_match = thought_match2
        if thought_match2:
            orig_text = thought_pattern.sub("", orig_text)
        orig_text = thought_unclosed_pattern.sub("", orig_text)
        orig_text = thought_strip_pattern.sub("", orig_text)
        
        # [调试] 打印 LLM 的完整输出
        logger.info(f"[WzlFavorability DEBUG] LLM 完整输出:\n{orig_text}")
        
        # ========== 提取思维链内容用于情感更新（不管是否显示） ==========
        updates = {}
        thought_content = None
        
        if thought_match:
            thought_content = thought_match.group(1)
            logger.info(f"[WzlFavorability DEBUG] 提取到的思维链内容:\n{thought_content}")
            
            lines = thought_content.split('\n')
            for i, line in enumerate(lines):
                line = line.strip()
                if not line: continue
                
                if "更新" in line or "Update" in line:
                    logger.info(f"[WzlFavorability DEBUG] >>> 命中更新行 [Line {i}]: {line}")
                    
                    matches = self.single_emotion_pattern.findall(line)
                    logger.info(f"[WzlFavorability DEBUG]     正则抓取结果: {matches}")
                    
                    for k, v in matches:
                        try:
                            k = k.lower()
                            if k in self.CN_TO_EN_MAP: k = self.CN_TO_EN_MAP[k]
                            updates[k] = int(v)
                        except ValueError: continue
        
        # 如果思维链里没找到更新，尝试全文扫描（旧兼容模式）
        if not updates:
            logger.warning("[WzlFavorability DEBUG] 思维链中未找到更新，尝试全文扫描(旧兼容模式)...")
            matches = self.single_emotion_pattern.findall(orig_text)
            for k, v in matches:
                 try:
                    k = k.lower()
                    if k in self.CN_TO_EN_MAP: k = self.CN_TO_EN_MAP[k]
                    updates[k] = int(v)
                 except ValueError: continue

        # ========== 第三轮：最终兜底清理（无条件移除所有 thought 痕迹） ==========
        orig_text = thought_pattern.sub("", orig_text)
        orig_text = thought_unclosed_pattern.sub("", orig_text)
        orig_text = thought_strip_pattern.sub("", orig_text)
        # [修复 v7.0.2] 移除误输出到正文的内部自检提示
        orig_text = self._sanitize_self_check(orig_text)
        
        # ========== 设置最终文本 ==========
        resp.completion_text = orig_text.strip()
        
        # 如果用户开启了心理显示，以受控格式重新附加 thought 内容
        if state.show_thought and thought_content:
            thought_display = f"\n\n【内心独白】\n{thought_content.strip()}"
            resp.completion_text = resp.completion_text + thought_display
        
        if updates:
            logger.info(f"[WzlFavorability] 最终捕获的情感变更: {updates}")
            self._apply_emotion_updates(state, updates)
            user_id = event.get_sender_id()
            self._update_interaction_stats(state, updates, user_id)
            await self.user_manager.update_user_state(user_key, state)
        else:
            logger.info("[WzlFavorability] 本次无情感变更。")
        
        if state.show_status and updates:
            user_id = event.get_sender_id()
            status_info = f"\n\n{self._format_emotional_state(state, user_id)}"
            resp.completion_text = resp.completion_text.rstrip() + status_info


    def _apply_emotion_updates(self, state: EmotionalState, updates: Dict[str, int]):
        # 定义一个简单的截断函数，限制变化幅度
        def _clamp(delta: int) -> int:
            return max(self.change_min, min(self.change_max, delta))

        all_dims = list(EmotionAnalyzer.TONE_INSTRUCTIONS.keys())
        for dim in all_dims:
            if dim in updates:
                # 1. 获取 LLM 输出的变化值
                raw_delta = updates[dim]
                # 2. 强制截断 (例如: 输出 20, 强行变成 5; 输出 -50, 强行变成 -10)
                safe_delta = _clamp(raw_delta)
                
                # 3. 应用更新并限制最终结果在 0-100 之间
                val = getattr(state, dim) + safe_delta
                setattr(state, dim, max(0, min(100, val)))
        
        if "favor" in updates:
            # 好感度同样应用截断
            safe_delta = _clamp(updates["favor"])
            state.favor = max(self.favour_min, min(self.favour_max, state.favor + safe_delta))
            
        if "intimacy" in updates:
            # 亲密度同样应用截断
            safe_delta = _clamp(updates["intimacy"])
            state.intimacy = max(0, min(100, state.intimacy + safe_delta))
            
        # 检查黑名单逻辑保持不变
        if state.favor <= self.favour_min and not state.is_blacklisted:
            state.is_blacklisted = True
            logger.info(f"[WzlFavorability] 用户 {state} 触发黑名单")

    def _update_interaction_stats(self, state: EmotionalState, updates: Dict[str, int], user_id: str = None):
        state.interaction_count += 1
        state.last_interaction = time.time()
        
        pos_score = sum(updates.get(k, 0) for k in ["joy", "trust", "favor"] if updates.get(k,0)>0)
        neg_score = sum(updates.get(k, 0) for k in ["anger", "disgust", "sadness"] if updates.get(k,0)>0)
        
        if pos_score > neg_score: state.positive_interactions += 1
        elif neg_score > pos_score: state.negative_interactions += 1
        
        state.attitude = self._calculate_attitude(state)
        state.relationship = self._calculate_relationship_level(state, user_id)

    # ==================== 指令开关判定 ====================
    def _is_admin(self, event: AstrMessageEvent) -> bool:
        uid = str(event.get_sender_id())
        return uid in self.admin_qq_list or uid in self.owner_qq_list

    def _command_allowed(self, event: AstrMessageEvent, name: str) -> bool:
        """管理员与主人不受限；其余人只能使用配置里开启的指令。"""
        if self._is_admin(event):
            return True
        flags = getattr(self, "command_flags", None)
        if flags is None:
            return True
        return bool(flags.get(name, True))

    def _deny_result(self, event: AstrMessageEvent, name: str):
        return event.plain_result(f"【{name}】暂未开启，先去找管理员吧。")

    # ==================== 注册命令 ====================
    
    @event_filter.command("好感度", priority=5)
    @event_filter.regex(r"^好感度$")
    async def cmd_show_state(self, event: AstrMessageEvent, _: str = ""):
        if not self._command_allowed(event, "好感度"):
            yield self._deny_result(event, "好感度")
            return
        async for r in self.user_commands.show_emotional_state(event): yield r

    @event_filter.command("状态显示", priority=5)
    async def cmd_toggle_status(self, event: AstrMessageEvent):
        if not self._command_allowed(event, "状态显示"):
            yield self._deny_result(event, "状态显示")
            return
        async for r in self.user_commands.toggle_status_display(event): yield r
        
    @event_filter.command("心理显示", priority=5) 
    async def cmd_toggle_thought(self, event: AstrMessageEvent):
        if not self._command_allowed(event, "心理显示"):
            yield self._deny_result(event, "心理显示")
            return
        async for r in self.user_commands.toggle_thought_display(event): yield r

    @event_filter.command("好感排行", priority=5)
    async def cmd_rank(self, event: AstrMessageEvent, num: str = "10"):
        if not self._command_allowed(event, "好感排行"):
            yield self._deny_result(event, "好感排行")
            return
        async for r in self.user_commands.show_favor_ranking(event, num): yield r

    @event_filter.command("负好感排行", priority=5)
    async def cmd_bad_rank(self, event: AstrMessageEvent, num: str = "10"):
        if not self._command_allowed(event, "负好感排行"):
            yield self._deny_result(event, "负好感排行")
            return
        async for r in self.user_commands.show_negative_favor_ranking(event, num): yield r
        
    @event_filter.command("黑名单统计", priority=5)
    async def cmd_black_stats(self, event: AstrMessageEvent):
        if not self._command_allowed(event, "黑名单统计"):
            yield self._deny_result(event, "黑名单统计")
            return
        async for r in self.user_commands.show_blacklist_stats(event): yield r

    @event_filter.command("缓存统计", priority=5)
    async def cmd_cache(self, event: AstrMessageEvent):
        if not self._command_allowed(event, "缓存统计"):
            yield self._deny_result(event, "缓存统计")
            return
        async for r in self.user_commands.show_cache_stats(event): yield r

    @event_filter.command("设置情感", priority=5)
    async def cmd_set_emotion(self, event: AstrMessageEvent, user: str, dim: str, val: str):
        if not self._command_allowed(event, "设置情感"):
            yield self._deny_result(event, "设置情感")
            return
        async for r in self.admin_commands.set_emotion(event, user, dim, val): yield r

    @event_filter.command("重置好感", priority=5)
    async def cmd_reset_favor(self, event: AstrMessageEvent, user: str):
        if not self._command_allowed(event, "重置好感"):
            yield self._deny_result(event, "重置好感")
            return
        async for r in self.admin_commands.reset_favor(event, user): yield r

    @event_filter.command("查看好感", priority=5)
    async def cmd_view_favor(self, event: AstrMessageEvent, user: str):
        if not self._command_allowed(event, "查看好感"):
            yield self._deny_result(event, "查看好感")
            return
        async for r in self.admin_commands.view_favor(event, user): yield r

    @event_filter.command("备份数据", priority=5)
    async def cmd_backup(self, event: AstrMessageEvent):
        if not self._command_allowed(event, "备份数据"):
            yield self._deny_result(event, "备份数据")
            return
        async for r in self.admin_commands.backup_data(event): yield r

    async def terminate(self):
        if hasattr(self, 'auto_save_task'): self.auto_save_task.cancel()
        await self.user_manager.force_save()
        logger.info("WzlFavorability 插件已安全关闭")


# ==================== 流式思维链过滤器（附加补丁，勿删） ====================
# 背景：核心的“发送前钩子”对流式输出不生效（result_decorate 遇到流式结果直接返回），
#       所以 on_decorating_result 清洗不到流式分块。
# 做法：插件加载时包装 webchat 的 send_streaming，逐块剥离 <thought> 等标签及其内容。
#       仅在内存中包装，不修改 AstrBot 的任何源码文件。

# 全局开关：由插件配置 thought_guard 控制，默认开启
_THOUGHT_GUARD_ENABLED = True
# 代码块（``` 围栏）内是否原样放行，避免误伤教程与代码
_THOUGHT_GUARD_KEEP_CODE = True
# 未闭合开始标签的处理策略
_THOUGHT_GUARD_UNCLOSED = "line_start"

_THOUGHT_STREAM_TAGS = ("thought", "think", "thinking", "reasoning")
_THOUGHT_STREAM_OPEN_RE = re.compile(
    r"<(" + "|".join(_THOUGHT_STREAM_TAGS) + r")\s*>",
    re.IGNORECASE,
)
_THOUGHT_STREAM_CLOSE_RE = re.compile(
    r"</(" + "|".join(_THOUGHT_STREAM_TAGS) + r")\s*>",
    re.IGNORECASE,
)
_FENCE = "```"


class _ThoughtStreamFilter:
    """跨分块识别思维链标签，并丢弃其中的内容。

    - 只认 thought / think / thinking / reasoning 四种标签，其余文字原样放行
    - 代码块（``` 围栏）内部一律原样放行，避免误伤教程、代码片段
    - 孤立的闭合标签会被删掉；未闭合的开始标签，其后内容全部视为思维链
    """

    TAG_NAMES = _THOUGHT_STREAM_TAGS

    def __init__(self, keep_code: bool = True, unclosed_policy: str = "line_start"):
        self.buf = ""
        self.in_thought = None
        self.in_fence = False
        self.keep_code = keep_code
        # 未闭合开始标签的处理：line_start=只有段落开头才吞后续 / always=一律吞 / tag_only=只删标签
        self.unclosed_policy = unclosed_policy
        # 当前是否处于“行首”（前面只有空白）
        self.line_start = True

    def _note_output(self, text: str) -> None:
        if not text:
            return
        idx = text.rfind("\n")
        if idx != -1:
            self.line_start = not text[idx + 1:].strip()
        elif text.strip():
            self.line_start = False

    def _trailing_partial_open(self) -> int:
        """末尾可能是标签开头时，返回需要暂留的长度。"""
        idx = self.buf.rfind("<")
        if idx == -1:
            return 0
        suffix = self.buf[idx:].lower()
        if len(suffix) > 24:
            return 0
        for name in self.TAG_NAMES:
            for candidate in (f"<{name}>", f"<{name} ", f"</{name}>", f"</{name} "):
                if candidate.startswith(suffix):
                    return len(suffix)
        return 0

    def _trailing_backticks(self) -> int:
        n = 0
        for ch in reversed(self.buf):
            if ch == "`":
                n += 1
            else:
                break
        return min(n, 3)

    def feed(self, text: str) -> str:
        if not text:
            return ""
        self.buf += text
        out = []

        while True:
            # ---------- 代码块内：原样放行，只找结束围栏 ----------
            if self.keep_code and self.in_fence:
                idx = self.buf.find(_FENCE)
                if idx == -1:
                    back = self._trailing_backticks()
                    if back:
                        self._note_output(self.buf[:-back])
                        out.append(self.buf[:-back])
                        self.buf = self.buf[-back:]
                    else:
                        self._note_output(self.buf)
                        out.append(self.buf)
                        self.buf = ""
                    return "".join(out)
                self._note_output(self.buf[: idx + len(_FENCE)])
                out.append(self.buf[: idx + len(_FENCE)])
                self.buf = self.buf[idx + len(_FENCE):]
                self.in_fence = False
                continue

            # ---------- 思维链内：一直吞到闭合标签 ----------
            if self.in_thought:
                close = f"</{self.in_thought}>"
                low = self.buf.lower()
                idx = low.find(close)
                if idx == -1:
                    keep = 0
                    for size in range(min(len(low), len(close) - 1), 0, -1):
                        if low.endswith(close[:size]):
                            keep = size
                            break
                    self.buf = self.buf[-keep:] if keep else ""
                    return "".join(out)
                self.buf = self.buf[idx + len(close):]
                self.in_thought = None
                continue

            # ---------- 普通文本：取最早发生的事件 ----------
            m_open = _THOUGHT_STREAM_OPEN_RE.search(self.buf)
            m_close = _THOUGHT_STREAM_CLOSE_RE.search(self.buf)
            pos_fence = self.buf.find(_FENCE) if self.keep_code else -1

            events = []
            if m_open:
                events.append((m_open.start(), "open"))
            if m_close:
                events.append((m_close.start(), "close"))
            if pos_fence != -1:
                events.append((pos_fence, "fence"))

            if not events:
                hold = self._trailing_partial_open()
                if self.keep_code:
                    hold = max(hold, self._trailing_backticks())
                if hold:
                    if hold < len(self.buf):
                        self._note_output(self.buf[:-hold])
                        out.append(self.buf[:-hold])
                    self.buf = self.buf[-hold:]
                else:
                    self._note_output(self.buf)
                    out.append(self.buf)
                    self.buf = ""
                return "".join(out)

            pos, kind = min(events, key=lambda x: x[0])
            self._note_output(self.buf[:pos])
            out.append(self.buf[:pos])

            if kind == "fence":
                self._note_output(_FENCE)
                out.append(_FENCE)
                self.buf = self.buf[pos + len(_FENCE):]
                self.in_fence = True
                continue

            if kind == "close":
                # 孤立的闭合标签：直接删掉
                self.buf = self.buf[pos + len(m_close.group(0)):]
                continue

            tag_text = m_open.group(0)
            if self.in_fence:
                # 代码块里的标签当普通文字
                self._note_output(tag_text)
                out.append(tag_text)
                self.buf = self.buf[pos + len(tag_text):]
                continue
            at_line_start = self.line_start
            self.buf = self.buf[pos + len(tag_text):]

            if self.unclosed_policy == "tag_only":
                # 只删标签，保留后面的文字
                continue
            if self.unclosed_policy == "line_start" and not at_line_start:
                # 句子中间的标签多半只是被提到，不吞后续内容
                continue
            self.in_thought = m_open.group(1).lower()

    def flush(self) -> str:
        if self.in_thought:
            self.buf = ""
            return ""
        rest, self.buf = self.buf, ""
        return rest


def _patch_webchat_streaming_thought() -> bool:
    """运行时包装 webchat 的 send_streaming，剥掉思维链。"""
    try:
        from astrbot.core.platform.sources.webchat.webchat_event import (
            WebChatMessageEvent,
        )
        from astrbot.api.event import MessageChain
    except Exception as exc:
        logger.debug(f"[WzlFavorability] 未找到 webchat 适配器，跳过流式清洗：{exc}")
        return False

    original = getattr(WebChatMessageEvent, "send_streaming", None)
    if original is None:
        return False
    if getattr(original, "__thought_stream_patched__", False):
        return True

    plain_cls = getattr(Comp, "Plain", None) if Comp is not None else None

    async def send_streaming(self, generator, use_fallback: bool = False):
        async def filtered():
            if not _THOUGHT_GUARD_ENABLED:
                # 开关关闭时原样透传，不做任何裁剪
                async for chain in generator:
                    yield chain
                return

            stream_filter = _ThoughtStreamFilter(
                keep_code=_THOUGHT_GUARD_KEEP_CODE,
                unclosed_policy=_THOUGHT_GUARD_UNCLOSED,
            )
            async for chain in generator:
                if getattr(chain, "type", "") == "reasoning":
                    # 思维链通道整块丢弃，顺带隐藏“思考了N次”面板
                    continue

                components = list(getattr(chain, "chain", []) or [])
                if components and plain_cls is not None:
                    kept = []
                    for component in components:
                        if isinstance(component, plain_cls):
                            cleaned = stream_filter.feed(component.text or "")
                            if not cleaned:
                                continue
                            component.text = cleaned
                            kept.append(component)
                        else:
                            kept.append(component)
                    if not kept:
                        continue
                    chain.chain = kept
                yield chain

            tail = stream_filter.flush()
            if tail.strip() and plain_cls is not None:
                yield MessageChain(chain=[plain_cls(tail)])

        await original(self, filtered(), use_fallback)

    send_streaming.__thought_stream_patched__ = True
    WebChatMessageEvent.send_streaming = send_streaming
    logger.info("[WzlFavorability] 已接管 webchat 流式输出，思维链将在发送途中被剥离。")
    return True


try:
    _patch_webchat_streaming_thought()
except Exception as _patch_err:  # 补丁失败不影响插件其他功能
    logger.warning(f"[WzlFavorability] 流式思维链补丁加载失败：{_patch_err}")
